$(document).ready(function(){
    $("#diagnostics").click(function(){
        $("main").load("diagnostics.html");
    });
});